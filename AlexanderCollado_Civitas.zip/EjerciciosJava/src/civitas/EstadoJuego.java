
package civitas;

//@author SatoriAlex // Alexander Collado Rojas Y7412507N

public enum EstadoJuego {
  INICIO_TURNO,
  DESPUES_AVANZAR,
  DESPUES_COMPRAR,
  DESPUES_GESTIONAR    
}
