
package civitas;

//@author SatoriAlex // Alexander Collado Rojas Y7412507N

public enum TipoCasilla {
    CALLE,
    SORPRESA,
    DESCANSO
}
