package civitas;

import java.util.Arrays;
import java.util.ArrayList;

import controladorCivitas.Controlador;
import vistaTextualCivitas.VistaTextual;


public class TestP4 {
    
     public static void main(String[] args) {
         
        //Jugador jugador --> Colocarlo como ArrayList
        /*
        CivitasJuego juegoModel = new CivitasJuego(nombres, false);
        VistaTextual vista = new VistaTextual(juegoModel);
        Controlador controlador = new Controlador(juegoModel,vista);*/
        
        //juegoModel.jugadorAEspeculador(0); //Pepe  pasa a ser especulador
        //juego.jugadorAEspeculador(2); //Marta pasa a ser especuladora
        
        //Dado.getInstance().setDebug(true);
        //controlador.juega();
     }
}